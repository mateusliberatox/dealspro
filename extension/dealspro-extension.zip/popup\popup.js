// ── DealsPro Extension Popup ─────────────────────────────────────────────────

const SUPABASE_URL  = 'https://ktgypsgwxumdobakyebn.supabase.co';
const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt0Z3lwc2d3eHVtZG9iYWt5ZWJuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ1NDczNDQsImV4cCI6MjA5MDEyMzM0NH0.ySFLxVz5bII76bu2TTrnNOc0LbmjmT_WI974zvqjO9o';

// ── Tabela de tarifas de frete por agente (CNY por pacote, destino: Brasil) ──
// base: taxa fixa de envio (CNY)
// perKg: taxa por kg adicional acima do peso mínimo (CNY/kg)
// minKg: peso mínimo cobrado
// Fonte: calculadoras públicas dos agentes (valores aproximados, atualizar periodicamente)
const AGENTS = {
  cssbuy: {
    name: 'CSBuy', url: 'https://www.cssbuy.com/estimates',
    methods: {
      'E-Packet BR':           { base: 28,  perKg: 22,  minKg: 0.1 },
      'Linha Brasil (CNE)':    { base: 35,  perKg: 22,  minKg: 0.1 },
      'YunExpress':            { base: 48,  perKg: 32,  minKg: 0.1 },
      'PostNL':                { base: 38,  perKg: 24,  minKg: 0.1 },
      'EMS':                   { base: 70,  perKg: 48,  minKg: 0.1 },
      'DHL Express':           { base: 120, perKg: 75,  minKg: 0.5 },
      'FedEx':                 { base: 135, perKg: 85,  minKg: 0.5 },
    },
  },
  pandabuy: {
    name: 'Pandabuy', url: 'https://www.pandabuy.com/freight-estimate',
    methods: {
      'Economy Line':          { base: 30,  perKg: 20,  minKg: 0.1 },
      'Linha Brasil':          { base: 38,  perKg: 24,  minKg: 0.1 },
      'YunExpress':            { base: 50,  perKg: 35,  minKg: 0.1 },
      'PostNL':                { base: 36,  perKg: 22,  minKg: 0.1 },
      'EMS':                   { base: 75,  perKg: 50,  minKg: 0.1 },
      'DHL Express':           { base: 130, perKg: 80,  minKg: 0.5 },
      'Frete Marítimo':        { base: 20,  perKg: 8,   minKg: 0.5 },
    },
  },
  sugargoo: {
    name: 'Sugargoo', url: 'https://www.sugargoo.com/#/home/freightEstimate',
    methods: {
      'E-Packet BR':           { base: 26,  perKg: 20,  minKg: 0.1 },
      'Linha Brasil':          { base: 36,  perKg: 22,  minKg: 0.1 },
      '4PX Standard':          { base: 45,  perKg: 30,  minKg: 0.1 },
      'PostNL':                { base: 32,  perKg: 19,  minKg: 0.1 },
      'EMS':                   { base: 68,  perKg: 46,  minKg: 0.1 },
      'DHL Express':           { base: 118, perKg: 72,  minKg: 0.5 },
    },
  },
  superbuy: {
    name: 'Superbuy', url: 'https://www.superbuy.com/en/page/freightestimate/',
    methods: {
      'Economy Line':          { base: 32,  perKg: 22,  minKg: 0.1 },
      'Linha Brasil Especial': { base: 40,  perKg: 25,  minKg: 0.1 },
      'YunExpress':            { base: 52,  perKg: 36,  minKg: 0.1 },
      'PostNL':                { base: 38,  perKg: 21,  minKg: 0.1 },
      'EMS':                   { base: 78,  perKg: 52,  minKg: 0.1 },
      'DHL Express':           { base: 125, perKg: 78,  minKg: 0.5 },
      'FedEx':                 { base: 140, perKg: 88,  minKg: 0.5 },
    },
  },
  wegobuy: {
    name: 'Wegobuy', url: 'https://www.wegobuy.com/en/page/freightestimate/',
    methods: {
      'Economy Line':          { base: 30,  perKg: 21,  minKg: 0.1 },
      'Linha Brasil Especial': { base: 36,  perKg: 22,  minKg: 0.1 },
      '4PX Standard':          { base: 48,  perKg: 33,  minKg: 0.1 },
      'PostNL':                { base: 34,  perKg: 20,  minKg: 0.1 },
      'EMS':                   { base: 72,  perKg: 48,  minKg: 0.1 },
      'DHL Express':           { base: 120, perKg: 74,  minKg: 0.5 },
    },
  },
  hagobuy: {
    name: 'Hagobuy', url: 'https://www.hagobuy.com/item/estimate_freight',
    methods: {
      'Economy Line':          { base: 28,  perKg: 20,  minKg: 0.1 },
      'Linha Brasil':          { base: 34,  perKg: 21,  minKg: 0.1 },
      'YunExpress':            { base: 46,  perKg: 30,  minKg: 0.1 },
      'PostNL':                { base: 35,  perKg: 20,  minKg: 0.1 },
      'EMS':                   { base: 68,  perKg: 46,  minKg: 0.1 },
      'DHL Express':           { base: 115, perKg: 72,  minKg: 0.5 },
    },
  },
  allchinabuy: {
    name: 'AllChinaBuy', url: 'https://www.allchinabuy.com/en/page/estimates/',
    methods: {
      'Economy (SAL)':         { base: 25,  perKg: 18,  minKg: 0.1 },
      'Linha Brasil':          { base: 33,  perKg: 20,  minKg: 0.1 },
      'YunExpress':            { base: 45,  perKg: 29,  minKg: 0.1 },
      'EMS':                   { base: 66,  perKg: 44,  minKg: 0.1 },
      'DHL Express':           { base: 112, perKg: 70,  minKg: 0.5 },
    },
  },
  // Um dos agentes mais usados pela comunidade BR atualmente (junto com
  // CSBuy/Pandabuy). Valores aproximados — Hoobuy não publica uma
  // calculadora pública detalhada por método como os demais agentes;
  // ajustar quando houver dados mais precisos.
  hoobuy: {
    name: 'Hoobuy', url: 'https://hoobuy.com/',
    methods: {
      'Linha Padrão':          { base: 27,  perKg: 19,  minKg: 0.1 },
      'Linha Brasil':          { base: 34,  perKg: 21,  minKg: 0.1 },
      'YunExpress':            { base: 46,  perKg: 30,  minKg: 0.1 },
      'EMS':                   { base: 70,  perKg: 47,  minKg: 0.1 },
      'DHL Express':           { base: 118, perKg: 73,  minKg: 0.5 },
    },
  },
  custom: {
    name: 'Personalizado', url: '',
    methods: { 'Personalizado': { base: 0, perKg: 0, minKg: 0 } },
  },
};

// ── Cotação ──────────────────────────────────────────────────────────────────

// NOTA: 0.82 é o câmbio de fallback CNY→BRL — duplicado em
// content/common.js e background.js (contextos isolados, sem módulos
// compartilhados). Mantenha os 3 sincronizados se este valor mudar.
let currentRate = 0.82;
chrome.storage.local.get(['cnyToBrl', 'rateUpdatedAt'], ({ cnyToBrl }) => {
  const chip = document.getElementById('rateChip');
  if (cnyToBrl) {
    currentRate = cnyToBrl;
    chip.textContent = `1 ¥ = R$ ${cnyToBrl.toFixed(4)}`;
  } else {
    chip.textContent = 'Sem cotação';
  }
});

// ── Tema ─────────────────────────────────────────────────────────────────────

chrome.storage.local.get('dpTheme', ({ dpTheme }) => {
  if (dpTheme === 'dark') {
    document.body.classList.add('dark');
    document.getElementById('themeBtn').textContent = '🌙';
  }
});

document.getElementById('themeBtn').addEventListener('click', () => {
  const dark = document.body.classList.toggle('dark');
  document.getElementById('themeBtn').textContent = dark ? '🌙' : '☀️';
  chrome.storage.local.set({ dpTheme: dark ? 'dark' : 'light' });
});

// ── Nav footer ────────────────────────────────────────────────────────────────

document.querySelectorAll('.nav-btn[data-page]').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach((b) => b.classList.remove('active'));
    document.querySelectorAll('.page').forEach((p) => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(`page-${btn.dataset.page}`).classList.add('active');
  });
});

// ── Tamanhos ──────────────────────────────────────────────────────────────────

document.querySelectorAll('.size-tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.size-tab').forEach((t) => t.classList.remove('active'));
    document.querySelectorAll('.size-panel').forEach((p) => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(`size-${tab.dataset.size}`).classList.add('active');
  });
});

// ── Toggle global ─────────────────────────────────────────────────────────────

chrome.storage.local.get('dpEnabled', ({ dpEnabled }) => {
  document.getElementById('globalToggle').checked = dpEnabled !== false;
});
document.getElementById('globalToggle').addEventListener('change', (e) => {
  chrome.storage.local.set({ dpEnabled: e.target.checked });
});

// ── Módulos ───────────────────────────────────────────────────────────────────

chrome.storage.local.get('dpModules', ({ dpModules }) => {
  const mods = dpModules ?? { converter: true, sizes: true, import: true, alerts: true };
  document.querySelectorAll('.feature-card[data-mod]').forEach((card) => {
    if (mods[card.dataset.mod] === false) card.classList.remove('active');
    else card.classList.add('active');
  });
});

document.querySelectorAll('.feature-card[data-mod]').forEach((card) => {
  card.addEventListener('click', () => {
    const isPremiumCard = !!card.querySelector('.badge-premium');
    if (isPremiumCard) {
      chrome.storage.local.get('dpPlan', ({ dpPlan }) => {
        if (dpPlan !== 'premium') {
          chrome.tabs.create({ url: 'https://dealspro-chi.vercel.app/upgrade' });
          return;
        }
        toggleCard(card);
      });
      return;
    }
    toggleCard(card);
  });
});

function toggleCard(card) {
  card.classList.toggle('active');
  chrome.storage.local.get('dpModules', ({ dpModules }) => {
    const curr = dpModules ?? {};
    curr[card.dataset.mod] = card.classList.contains('active');
    chrome.storage.local.set({ dpModules: curr });
  });
}

// ── Busca inteligente PT→ZH ───────────────────────────────────────────────────
// Chama a API direto do popup — evita depender do service worker (MV3 dorme)

const DEALSPRO_API = 'https://dealspro-chi.vercel.app';

const SEARCH_URLS = {
  taobao:  (q) => `https://s.taobao.com/search?q=${encodeURIComponent(q)}`,
  goofish: (q) => `https://www.goofish.com/search?q=${encodeURIComponent(q)}`,
  '1688':  (q) => `https://s.1688.com/selloffer/offerlist.htm?keywords=${encodeURIComponent(q)}`,
};

document.getElementById('searchBtn').addEventListener('click', async () => {
  const text    = document.getElementById('searchInput').value.trim();
  const site    = document.getElementById('searchSite').value;
  const result  = document.getElementById('searchResult');
  const errEl   = document.getElementById('searchError');
  const transEl = document.getElementById('searchTranslated');
  const btn     = document.getElementById('searchBtn');

  if (!text) return;
  errEl.style.display = 'none'; result.style.display = 'none';
  btn.textContent = '…'; btn.disabled = true;

  try {
    const res  = await fetch(`${DEALSPRO_API}/api/extension/translate`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ text }),
      signal:  AbortSignal.timeout(10_000),
    });
    const data = await res.json();
    if (!res.ok || !data.translated) throw new Error('sem tradução');

    transEl.textContent  = data.translated;
    result.style.display = 'block';
    chrome.tabs.create({ url: SEARCH_URLS[site]?.(data.translated) ?? SEARCH_URLS.taobao(data.translated) });
  } catch {
    errEl.textContent = 'Falha na tradução. Verifique sua conexão.';
    errEl.style.display = 'block';
  } finally {
    btn.textContent = 'Buscar'; btn.disabled = false;
  }
});

document.getElementById('searchInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') document.getElementById('searchBtn').click();
});

// ── Rastreamento — chama a API diretamente do popup ───────────────────────────

document.querySelectorAll('.nav-btn[data-page]').forEach((btn) => {
  btn.addEventListener('click', () => {
    if (btn.dataset.page === 'orders') loadOrders();
  });
});

document.getElementById('ordersRefreshBtn').addEventListener('click', loadOrders);

// Escapa caracteres HTML especiais antes de interpolar strings vindas da API
// (description/lastEvent podem conter texto livre — sem isso, um valor como
// "<img src=x onerror=...>" seria executado dentro do innerHTML do popup).
function escapeHtml(str) {
  return String(str ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

async function loadOrders() {
  const wrap = document.getElementById('ordersWrap');
  wrap.innerHTML = '<p style="font-size:11px;color:var(--text3);text-align:center;padding:20px 0">Carregando…</p>';

  // Garante que a sessão já foi restaurada/renovada antes de ler o token —
  // evita usar um dpToken expirado se o usuário clicar em "Pedidos" logo
  // ao abrir o popup.
  await sessionReady;

  const { dpToken } = await chrome.storage.local.get('dpToken');
  if (!dpToken) {
    wrap.innerHTML = '<p style="font-size:11px;color:var(--text3);text-align:center;padding:16px 0">Faça login para ver seus pedidos.</p>';
    return;
  }

  try {
    const res    = await fetch(`${DEALSPRO_API}/api/extension/orders`, {
      headers: { Authorization: `Bearer ${dpToken}` },
      signal:  AbortSignal.timeout(8_000),
    });
    const data   = await res.json();
    const orders = data?.orders ?? [];

    if (!orders.length) {
      wrap.innerHTML = '<p style="font-size:11px;color:var(--text3);text-align:center;padding:16px 0">Nenhuma encomenda em trânsito.</p>';
      return;
    }

    wrap.innerHTML = orders.map((o) => `
      <div style="padding:9px 10px;border-radius:9px;background:var(--bg2);border:1px solid var(--border);margin-bottom:6px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:6px">
          <span style="font-size:11px;font-weight:700;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(o.description)}</span>
          <span style="font-size:10px;font-weight:700;padding:2px 7px;border-radius:6px;background:var(--accent-bg);color:var(--accent);white-space:nowrap;flex-shrink:0">${escapeHtml(o.statusLabel)}</span>
        </div>
        <div style="font-size:10px;color:var(--text3);margin-top:3px">${escapeHtml(o.code)}</div>
        ${o.lastEvent ? `<div style="font-size:10px;color:var(--text2);margin-top:4px">↳ ${escapeHtml(o.lastEvent)}</div>` : ''}
      </div>
    `).join('');
  } catch {
    wrap.innerHTML = '<p style="font-size:11px;color:#ef4444;text-align:center;padding:16px 0">Erro ao carregar. Tente novamente.</p>';
  }
}

// ── Configurações de frete ────────────────────────────────────────────────────

const agentSel    = document.getElementById('agentSelect');
const methodSel   = document.getElementById('methodSelect');
const weightInp   = document.getElementById('weightInput');
const weightPresetsEl = document.getElementById('weightPresets');
const customGrp   = document.getElementById('customGroup');
const customInp   = document.getElementById('customFreight');
const customPer100gInp = document.getElementById('customPer100g');
const calcLink    = document.getElementById('agentCalcLink');

function buildMethodOptions(agentKey) {
  const agent = AGENTS[agentKey];
  methodSel.innerHTML = '';
  Object.keys(agent.methods).forEach((m) => {
    const opt = document.createElement('option');
    opt.value = m; opt.textContent = m;
    methodSel.appendChild(opt);
  });
  calcLink.href = agent.url || '#';
  calcLink.style.display = agent.url ? 'block' : 'none';
  customGrp.style.display = agentKey === 'custom' ? 'block' : 'none';
}

function calcFreight(agentKey, methodName, weightGrams) {
  if (agentKey === 'custom') {
    // Se o usuário preencheu "Valor por 100g", o frete é proporcional ao
    // peso do pacote — útil quando o valor fixo de referência está
    // desatualizado em relação à tarifa real do agente.
    const per100g = parseFloat(customPer100gInp?.value);
    if (per100g > 0) {
      const brl = parseFloat(((weightGrams / 100) * per100g).toFixed(2));
      return { cny: null, brl };
    }
    const val = parseFloat(customInp.value) || 80;
    return { cny: null, brl: val };
  }
  const method = AGENTS[agentKey]?.methods[methodName];
  if (!method) return { cny: 80, brl: 80 * currentRate };
  const kg    = Math.max(method.minKg, weightGrams / 1000);
  const cny   = method.base + method.perKg * (kg - method.minKg);
  return { cny: Math.round(cny), brl: parseFloat((cny * currentRate).toFixed(2)) };
}

// Marca o botão de peso pré-definido correspondente ao valor atual de
// weightInp (se houver um exatamente igual) e desmarca os demais.
function syncWeightPresets() {
  const grams = parseInt(weightInp.value) || 0;
  weightPresetsEl.querySelectorAll('.weight-preset').forEach((btn) => {
    btn.classList.toggle('active', parseInt(btn.dataset.grams) === grams);
  });
}

function updatePreview() {
  const agentKey  = agentSel.value;
  const method    = methodSel.value;
  const weightG   = Math.max(10, parseInt(weightInp.value) || 500);
  const freight   = calcFreight(agentKey, method, weightG);

  const TAX_THRESH_USD = 50;
  // Produto fictício de R$ 150 para mostrar exemplo
  const prodBrl = 150;
  // 5.8 é uma aproximação fixa do câmbio USD→BRL, usada só para estimar se o
  // produto-exemplo passaria do limiar de imposto. Independente das taxas
  // CNY→USD aproximadas usadas em goofish.js (cny*0.14) e cn-common.js
  // (1/7.15) — aqui o ponto de partida já é BRL, não CNY.
  const prodUsd = prodBrl / 5.8;
  const hasTax  = prodUsd > TAX_THRESH_USD;
  const taxBrl  = hasTax ? prodBrl * 0.6 : 0;
  const totalBrl = prodBrl + freight.brl + taxBrl;

  const rows = document.getElementById('shippingRows');
  rows.innerHTML = `
    <div class="shipping-row"><span>Produto (ex: R$ 150,00)</span><span>R$ 150,00</span></div>
    <div class="shipping-row">
      <span>Frete ${freight.cny ? `(¥${freight.cny} × câmbio)` : '(personalizado)'}</span>
      <span>R$ ${freight.brl.toFixed(2).replace('.', ',')}</span>
    </div>
    <div class="shipping-row"><span>Imposto (ex, prod. > US$50)</span><span style="color:#ef4444">R$ ${taxBrl.toFixed(2).replace('.', ',')}</span></div>
    <div class="shipping-row"><span>Total estimado</span><span>R$ ${totalBrl.toFixed(2).replace('.', ',')}</span></div>
  `;

  // Salva configuração + valor calculado para uso nos content scripts
  chrome.storage.local.set({
    dpShipping: {
      agent: agentKey, method, weightG,
      customBrl: parseFloat(customInp.value) || 80,
      customPer100g: parseFloat(customPer100gInp?.value) || 0,
    },
    dpShippingBrl: freight.brl,
  });
}

// Carrega configuração salva
chrome.storage.local.get('dpShipping', ({ dpShipping }) => {
  const cfg = dpShipping ?? { agent: 'cssbuy', method: 'E-Packet BR', weightG: 500, customBrl: 80, customPer100g: 0 };
  agentSel.value  = cfg.agent  ?? 'cssbuy';
  weightInp.value = cfg.weightG ?? 500;
  customInp.value = cfg.customBrl ?? 80;
  if (customPer100gInp) customPer100gInp.value = cfg.customPer100g || '';
  buildMethodOptions(agentSel.value);
  // Seleciona método salvo
  for (const opt of methodSel.options) {
    if (opt.value === cfg.method) { opt.selected = true; break; }
  }
  syncWeightPresets();
  updatePreview();
});

agentSel.addEventListener('change',  () => { buildMethodOptions(agentSel.value); updatePreview(); });
methodSel.addEventListener('change', updatePreview);
weightInp.addEventListener('input',  () => { syncWeightPresets(); updatePreview(); });
customInp.addEventListener('input',  updatePreview);
customPer100gInp?.addEventListener('input', updatePreview);

weightPresetsEl.querySelectorAll('.weight-preset').forEach((btn) => {
  btn.addEventListener('click', () => {
    weightInp.value = btn.dataset.grams;
    syncWeightPresets();
    updatePreview();
  });
});

// ── Auth helpers ──────────────────────────────────────────────────────────────

function showAccount(email, plan) {
  document.getElementById('login-section').style.display   = 'none';
  document.getElementById('account-section').style.display = 'block';
  document.getElementById('accountEmail').textContent = email || '—';
  document.getElementById('accountPlan').textContent  =
    plan === 'premium' ? '★ Premium ativo' : 'Plano Free';
  const av = document.getElementById('accountAvatar');
  if (av && email) av.textContent = email.charAt(0).toUpperCase();
  const dot = document.getElementById('statusDot');
  dot.textContent = plan === 'premium' ? '★ Premium' : 'Conectado';
  dot.className   = 'status-dot connected';
}

function showLogin() {
  document.getElementById('login-section').style.display   = 'block';
  document.getElementById('account-section').style.display = 'none';
  const dot = document.getElementById('statusDot');
  dot.textContent = 'Sem login'; dot.className = 'status-dot disconnected';
}

async function finishLogin(accessToken, refreshToken) {
  const errEl = document.getElementById('loginError');
  try {
    const userRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: { Authorization: `Bearer ${accessToken}`, apikey: SUPABASE_ANON },
    });
    const user = await userRes.json();
    if (!user?.id) throw new Error('Inválido');
    const profRes  = await fetch(
      `${SUPABASE_URL}/rest/v1/dealspro_profiles?user_id=eq.${user.id}&select=plan&limit=1`,
      { headers: { apikey: SUPABASE_ANON, Authorization: `Bearer ${accessToken}` } },
    );
    const plan = (await profRes.json())?.[0]?.plan ?? 'free';
    await chrome.storage.local.set({
      dpToken: accessToken,
      dpRefreshToken: refreshToken ?? null,
      dpEmail: user.email,
      dpPlan: plan,
    });
    showAccount(user.email, plan);
  } catch {
    errEl.textContent = 'Erro ao obter dados. Tente novamente.';
    errEl.style.display = 'block';
  }
}

// Troca um refresh token por um novo access token via Supabase Auth.
// Retorna { access_token, refresh_token, ... } em sucesso, ou null se o
// refresh token também estiver inválido/expirado (força novo login).
async function refreshSession(refreshToken) {
  try {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json', apikey: SUPABASE_ANON },
      body:    JSON.stringify({ refresh_token: refreshToken }),
      signal:  AbortSignal.timeout(8_000),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data?.access_token ? data : null;
  } catch {
    return null;
  }
}

// ── Discord OAuth ─────────────────────────────────────────────────────────────

document.getElementById('discordBtn').addEventListener('click', () => {
  const errEl = document.getElementById('loginError');
  const btn   = document.getElementById('discordBtn');
  errEl.style.display = 'none'; btn.textContent = 'Abrindo Discord…'; btn.disabled = true;
  const redirectUrl = chrome.identity.getRedirectURL();
  const authUrl = `${SUPABASE_URL}/auth/v1/authorize?` + new URLSearchParams({
    provider: 'discord', redirect_to: redirectUrl, scopes: 'identify email',
  });
  chrome.identity.launchWebAuthFlow({ url: authUrl, interactive: true }, async (responseUrl) => {
    btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 127.14 96.36" fill="white"><path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z"/></svg> Entrar com Discord`;
    btn.disabled = false;
    if (chrome.runtime.lastError || !responseUrl) { errEl.textContent = 'Login cancelado.'; errEl.style.display = 'block'; return; }
    try {
      const url   = new URL(responseUrl);
      const hash  = new URLSearchParams(url.hash.slice(1));
      const query = new URLSearchParams(url.search);
      const token        = hash.get('access_token') || query.get('access_token');
      const refreshToken = hash.get('refresh_token') || query.get('refresh_token');
      if (!token) throw new Error('Token não encontrado');
      await finishLogin(token, refreshToken);
    } catch { errEl.textContent = 'Erro no login. Tente novamente.'; errEl.style.display = 'block'; }
  });
});

// ── Email/senha ───────────────────────────────────────────────────────────────

document.getElementById('toggleEmailBtn').addEventListener('click', () => {
  const form = document.getElementById('emailForm');
  const btn  = document.getElementById('toggleEmailBtn');
  const open = form.style.display !== 'block';
  form.style.display = open ? 'block' : 'none';
  btn.textContent    = open ? '✉️ Entrar com e-mail ▴' : '✉️ Entrar com e-mail ▾';
});

document.getElementById('loginBtn').addEventListener('click', async () => {
  const email = document.getElementById('emailInput').value.trim();
  const pass  = document.getElementById('passInput').value;
  const errEl = document.getElementById('loginError');
  errEl.style.display = 'none';
  if (!email || !pass) { errEl.textContent = 'Preencha e-mail e senha.'; errEl.style.display = 'block'; return; }
  const btn = document.getElementById('loginBtn');
  btn.textContent = 'Entrando…'; btn.disabled = true;
  try {
    const res  = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', apikey: SUPABASE_ANON },
      body: JSON.stringify({ email, password: pass }),
    });
    const data = await res.json();
    if (!res.ok) { errEl.textContent = data.error_description ?? 'E-mail ou senha incorretos.'; errEl.style.display = 'block'; return; }
    await finishLogin(data.access_token, data.refresh_token);
  } catch { errEl.textContent = 'Erro de conexão.'; errEl.style.display = 'block'; }
  finally { btn.textContent = 'Entrar'; btn.disabled = false; }
});

// ── Sessão salva + logout ─────────────────────────────────────────────────────

function isTokenExpired(token) {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    return payload.exp * 1000 < Date.now();
  } catch { return true; }
}

// Promise resolvida quando a sessão salva já foi restaurada/renovada (ou
// confirmada como inválida). Outras partes do popup (ex.: loadOrders) que
// dependem de `dpToken` no storage devem esperar por ela primeiro — sem
// isso, um clique rápido em "Pedidos" logo após abrir o popup podia ler o
// token antigo (já expirado) antes do refresh terminar.
const sessionReady = (async () => {
  const { dpToken, dpRefreshToken, dpEmail, dpPlan } =
    await chrome.storage.local.get(['dpToken', 'dpRefreshToken', 'dpEmail', 'dpPlan']);

  if (!dpToken || !dpEmail) { showLogin(); return; }

  if (!isTokenExpired(dpToken)) {
    showAccount(dpEmail, dpPlan ?? 'free');
    return;
  }

  // Token expirado — tenta renovar com o refresh token antes de exigir
  // login novamente.
  if (dpRefreshToken) {
    const refreshed = await refreshSession(dpRefreshToken);
    if (refreshed) {
      await chrome.storage.local.set({
        dpToken: refreshed.access_token,
        dpRefreshToken: refreshed.refresh_token ?? dpRefreshToken,
      });
      showAccount(dpEmail, dpPlan ?? 'free');
      return;
    }
  }

  await chrome.storage.local.remove(['dpToken', 'dpRefreshToken', 'dpEmail', 'dpPlan']);
  showLogin();
})();

document.getElementById('logoutBtn').addEventListener('click', () => {
  chrome.storage.local.remove(['dpToken', 'dpRefreshToken', 'dpEmail', 'dpPlan'], showLogin);
});
